import sqlite3
conn = sqlite3.connect("database.db")
cursor = conn.cursor()
cursor.execute("INSERT INTO WORKING_HOUR (center_id, day, open_time, close_time) VALUES (?, ?, ?, ?)", (2, "Tuesday", "8.00am", "2.00am"))
cursor.execute("SELECT * FROM WORKING_HOUR")
print(cursor.fetchall())
conn.commit()