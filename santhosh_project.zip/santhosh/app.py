from flask import *
import sqlite3
import uuid
import json

app = Flask(__name__)
DB_FILE = 'database.db'


#table initialisation
def initialize():
    conn = sqlite3.connect(DB_FILE)
    cursor = conn.cursor()
    cursor.execute("CREATE TABLE IF NOT EXISTS USER_TABLE (id VARCHAR(255) PRIMARY KEY, name VARCHAR(255) NOT NULL, email VARCHAR(255) NOT NULL, password VARCHAR(255) NOT NULL, age INTEGER, state VARCHAR(255) NOT NULL, city VARCHAR(255) NOT NULL, date INTEGER)")
    cursor.execute("CREATE TABLE IF NOT EXISTS VACCINE_CENTERS(center_id VARCHAR(255) PRIMARY KEY, center_name VARCHAR(255) NOT NULL, location VARCHAR(255) NOT NULL)")
    cursor.execute("CREATE TABLE IF NOT EXISTS WORKING_HOUR(center_id VARCHAR(255), day VARCHAR(255), open_time VARCHAR(255), close_time VARCHAR(255), FOREIGN KEY (center_id) REFERENCES VACCINE_CENTERS(center_id))")

    cursor.execute("SELECT DISTINCT location from VACCINE_CENTERS")
    centers = cursor.fetchall();

    cursor.execute("SELECT DISTINCT open_time, close_time from WORKING_HOUR")
    working = cursor.fetchall();

    conn.commit()
    conn.close()

    return centers, working


#primary key generation
def generate_unique_id():
    return str(uuid.uuid4())


#adding a user data in database
def create_record(name, email, password, age, state, city, dob):
    conn = sqlite3.connect(DB_FILE)
    cursor = conn.cursor()
    id = generate_unique_id()
    cursor.execute("INSERT INTO USER_TABLE (id, name, email, password, age, state, city,date) VALUES (?, ?, ?, ?, ?, ?, ?, ?)", (id, name, email, password, age, state, city, dob))
    conn.commit()
    conn.close()


#path to the home page
@app.route("/")
def index():
    centers, working = initialize()
    print(working)
    return render_template("home.html", centers = centers, working = working)


#path to the signup page
@app.route('/signup')
def signup():
    return render_template('summa.html')


#path to the login page
@app.route('/login')
def login():
    return render_template('login.html')
        

#path to validate when user is signed in or not during login
@app.route('/validate_login', methods=['POST'])
def validate_login():
    if(request.method == 'POST'):
        name = request.form.get('username')
        password = request.form.get('password')
        con = sqlite3.connect(DB_FILE)
        cur = con.cursor()
        cur.execute('SELECT name, password FROM USER_TABLE where name = ? and password = ?', (name, password))
        ret = cur.fetchone()
        if(ret):
            return ""
        else:
            return "failed"



#path to create the credentials
@app.route('/create', methods=['POST'])
def create():
    if(request.method == 'POST'):
        name = request.form.get('fullname')
        email = request.form.get('email')
        password = request.form.get('password')
        age = request.form.get('age')
        state = request.form.get('state')
        city = request.form.get('city')
        dob = request.form.get('dob')
        
        create_record(name, email, password, age, state, city, dob)
    return "Record created successfully."


@app.route('/search', methods=['POST'])
def search():
    if(request.method == 'POST'):
        data = {1: "hello"}
        return jsonify(data)

if __name__ == '__main__':
    app.run(debug=True)
